<p>Name: <?php echo e($data['name']); ?></p>
<p>Email: <?php echo e($data['email']); ?></p>
<p>Subject: <?php echo e($data['subject']); ?>.</p>
<p>Message: <?php echo e($data['message']); ?>.</p><?php /**PATH C:\Users\bhsc1\OneDrive\Desktop\UniVis_firebase\resources\views\dynamic_email_template.blade.php ENDPATH**/ ?>