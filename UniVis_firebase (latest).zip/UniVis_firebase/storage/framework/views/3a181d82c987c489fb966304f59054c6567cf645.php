

<?php $__env->startSection('content'); ?>
<!--content-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.graph_lay2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bhsc1\OneDrive\Desktop\UniVis_firebase\resources\views\uni_page_v2.blade.php ENDPATH**/ ?>