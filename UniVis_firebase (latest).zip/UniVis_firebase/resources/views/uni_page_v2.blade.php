@extends('layouts.graph_lay2')

@section('content')
<!--content-->


@endsection